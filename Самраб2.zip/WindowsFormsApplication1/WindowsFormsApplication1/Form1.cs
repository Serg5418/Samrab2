﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsForms
{
    public partial class Form1 : Form
    {
        string fio = "", group = "";
        public Form1()
        {
            InitializeComponent();
            StartTest.Enabled = false;
            this.Hide();
        }

        void EnabledTest()
        {
            if (fio.Length > 3 && group.Length > 3)
            {
                StartTest.Enabled = true;
            }
        }

        private void TextChangedEventArgs(object sender, EventArgs e)
        {
        }

        void RecordFile()
        {
            StreamWriter resultFile;
            if (File.Exists(@"../result.txt"))
                resultFile = File.AppendText(@"../result.txt");
            else
                resultFile = File.CreateText(@"../result.txt");
            resultFile.WriteLine("Студент: " + fio);
            resultFile.WriteLine("Группа " + group);
            resultFile.Close();
        }

		private void Form1_Load(object sender, EventArgs e)
		{

		}

		private void textBox2_TextChanged(object sender, EventArgs e)
		{
			fio = textBox1.Text;
			group = textBox2.Text;
			EnabledTest();
		}

		private void StartTest_Click(object sender, EventArgs e)
		{
			RecordFile();
			 Form resultForm = Application.OpenForms[0];
			  this.Close();
			 resultForm.StartPosition = FormStartPosition.Manual;
			resultForm.Left = Left;
			  resultForm.Top = this.Top;
			 resultForm.Show();
		}

		private void textBox1_TextChanged(object sender, EventArgs e)
		{
			fio = textBox1.Text;
			group = textBox2.Text;
			EnabledTest();
		}
    }
}
