﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsForms
{
    struct vopros
    {
        public string vopr;
        public string otv1;
        public double bal1;
        public string otv2;
        public double bal2;
        public string otv3;
        public double bal3;
        public string otv4;
        public double bal4;
        public double rez;
        public int answer;
    }
    public partial class Form2 : Form
    {
        vopros[] Test;
        int numbQuest, i;
        string[] str;
        List<Button> vopr = new List<Button>();
        int timer = 0, timerMin = 0, timerSec = 0;
        string minutes = null;
        string secunds = null;
        string finishQuestions = null;
        double finishSum = 0;
        int currentQuestion = 0;
        bool finishProgram = false;

        public Form2()
        {
            InitializeComponent();
            Shown += new EventHandler(Form1_Shown);
            str = File.ReadAllLines(@"../test.txt",Encoding.Default);
            int n = str.Length, m = 0;
            numbQuest = n / 9;
            //for (int buttonNumb = 0; buttonNumb < numbQuest; buttonNumb++)
          //  {
             //   Button b = new Button();
              //  b.Name = "buttonQuestion" + buttonNumb;
             //   b.Height = 35;
             //   b.Width = 35;
             //   b.Top = this.ClientSize.Height - 120;
             //   b.Left = 20 + buttonNumb * 50;
              //  b.Text = Convert.ToString(buttonNumb + 1);
             //   b.Visible = true;
             //   b.Enabled = true;
             //   b.Click += new EventHandler(RetunQuestion);
             //   this.Controls.Add(b);
             //   vopr.Add(b);
         //   }
            Test = new vopros[numbQuest];
            for (int question = 0; question < numbQuest; question++)
            {
                Test[question].vopr = str[m]; m++;
                Test[question].otv1 = str[m]; m++;
                Test[question].bal1 = Convert.ToDouble(str[m]); m++;
                Test[question].otv2 = str[m]; m++;
                Test[question].bal2 = Convert.ToDouble(str[m]); m++;
                Test[question].otv3 = str[m]; m++;
                Test[question].bal3 = Convert.ToDouble(str[m]); m++;
                Test[question].otv4 = str[m]; m++;
                Test[question].bal4 = Convert.ToDouble(str[m]); m++;
                Test[question].answer = 0;
            }
            i = 0;
            vivod(i);
            timer1.Enabled = true;
        }

        void Form1_Shown(object sender, EventArgs e)
        {
            this.Hide();
            Form registrationForm = new Form1();
            registrationForm.StartPosition = FormStartPosition.Manual;
            registrationForm.Left = this.Left;
            registrationForm.Top = this.Top;
            registrationForm.Show();
        }
        void vivod(int t)
        {
            
            textBox1.Text = Test[t].vopr;
            radioButton1.Text = Test[t].otv1;
            radioButton2.Text = Test[t].otv2;
            radioButton3.Text = Test[t].otv3;
            radioButton4.Text = Test[t].otv4;
            switch (Test[t].answer)
            {
                case 1:
                    radioButton1.Checked = true;
                    radioButton2.Checked = false;
                    radioButton3.Checked = false;
                    radioButton4.Checked = false;
                    break;
                case 2:
                    radioButton1.Checked = false;
                    radioButton2.Checked = true;
                    radioButton3.Checked = false;
                    radioButton4.Checked = false;
                    break;
                case 3:
                    radioButton1.Checked = false;
                    radioButton2.Checked = false;
                    radioButton3.Checked = true;
                    radioButton4.Checked = false;
                    break;
                case 4:
                    radioButton1.Checked = false;
                    radioButton2.Checked = false;
                    radioButton3.Checked = false;
                    radioButton4.Checked = true;
                    break;
                default:
                    radioButton1.Checked = false;
                    radioButton2.Checked = false;
                    radioButton3.Checked = false;
                    radioButton4.Checked = false;
                    break;
            }
           
        }
		private void button1_Click(object sender, EventArgs e)
		{
			double s = 0;
			if (radioButton1.Checked) s += Test[i].bal1;
			if (radioButton2.Checked) s += Test[i].bal2;
			if (radioButton3.Checked) s += Test[i].bal3;
			if (radioButton4.Checked) s += Test[i].bal4;
			Test[i].rez = s;
			Test[i].answer = radioButton1.Checked ? 1 : radioButton2.Checked ? 2 : radioButton3.Checked ? 3 : radioButton4.Checked ? 4 : 0;
			i++;

			if (i < numbQuest)
			{
				vivod(i);
				currentQuestion = i;
				//disableButton();
			}
			if (i >= 1 && i < numbQuest) button3.Visible = true;
            if (i == numbQuest) button1.Visible = false;
        }
        //void disableButton()
      //  {
          //  if (i == numbQuest - 1)
         //   {
         //       button1.Enabled = false;
         //   }
       //     else
      //      {
        //        button1.Enabled = true;
        //    }
         //   int countGrenButton = 0;
        //    for (int k = 0; k < 20; k++)
        //    {
        //        if (Controls["buttonQuestion" + k].BackColor == Color.LightGreen)
          //      {
         //           countGrenButton++;
         //       }
         //   }
         //   if (countGrenButton == 20)
         //   {
         //       button2.Enabled = true;
        //    }
       // }

        private void RetunQuestion(object sender, EventArgs e)
        {
            double s = 0;
            if (radioButton1.Checked) s += Test[i].bal1;
            if (radioButton2.Checked) s += Test[i].bal2;
            if (radioButton3.Checked) s += Test[i].bal3;
            if (radioButton4.Checked) s += Test[i].bal4;
            Test[i].rez = s;
            Test[i].answer = radioButton1.Checked ? 1 : radioButton2.Checked ? 2 : radioButton3.Checked ? 3 : radioButton4.Checked ? 4 : 0;
            int k = 0;
            for (int j = 0; j < 20; j++)
            {
                if (sender.Equals(vopr[j]))
                {
                    k = j;
                }
            }
            vivod(k);
            currentQuestion = k;
            i = currentQuestion;
			//disableButton();
		}

		void TimerCalculation()
        {
            double min = timer / 60;
            double sec = timer % 60;
            timerMin = (int)Math.Ceiling(min);
            timerSec = Convert.ToInt32(sec);
        }

        void MinutesAndSeconds()
        {
            minutes = timerMin > 1 && timerMin < 5 ? "минуты" : timerMin == 1 ? "минуту" : "минут";
            secunds = (timerSec == 1 || timerSec == 21 || timerSec == 31 || timerSec == 41 || timerSec == 51) ? "секунду"
                    : ((timerSec > 1 && timerSec < 5) || (timerSec > 21 && timerSec < 25) || (timerSec > 31 && timerSec < 35) || (timerSec > 41 && timerSec < 45)) ? "секунды"
                    : "секунд";
            finishQuestions = finishSum == 1 ? "вопрос" : finishSum > 1 && finishSum < 5 ? "вопроса" : "вопросов";
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            Controls["buttonQuestion" + currentQuestion].BackColor = Color.LightGreen;
            if (!finishProgram)
            {
                //disableButton();
            }

        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            Controls["buttonQuestion" + currentQuestion].BackColor = Color.LightGreen;
            if (!finishProgram)
            {
                //disableButton();
            }
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            Controls["buttonQuestion" + currentQuestion].BackColor = Color.LightGreen;
            if (!finishProgram)
            {
                //disableButton();
            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
           // Controls["buttonQuestion" + currentQuestion].BackColor = Color.LightGreen;
         //   if (!finishProgram)
          //  {
                //disableButton();
          //  }
        }
        void RecordFile(double a, int b)
        {
            MinutesAndSeconds();
            StreamWriter resultFile;
            resultFile = File.AppendText(@"../../../result.txt");
            resultFile.WriteLine("Ответил на " + b + " " + finishQuestions + ". Оценка " + a);
            resultFile.WriteLine("Время выполнения " + timerMin + " " + minutes + " " + timerSec + " " + secunds);
            resultFile.Close();
        }

      //  void disabledButton()
      //  {
        //    for (int k = 0; k < 20; k++)
       //     {
        //        Controls["buttonQuestion" + k].Enabled = false;
       //     }
        //    button1.Enabled = false;
        //    button2.Enabled = false;
        //    finishProgram = true;
        //}

		private void button2_Click(object sender, EventArgs e)
		{
			double resultPercentage;
			for (int j = 0; j < numbQuest; j++)
			{
				finishSum += Test[j].rez;
			}
			resultPercentage = finishSum > 18 ? 5 : finishSum > 16 ? 4 : finishSum > 14 ? 3 : 2;
			TimerCalculation();
			timer1.Enabled = false;
			RecordFile(resultPercentage, finishSum);
			MinutesAndSeconds();
			MessageBox.Show("Тест закончен. Вы ответили на " + finishSum + " " + finishQuestions + ". Ваша оценка " + resultPercentage + "\nВремя выполнения " + timerMin + " " + minutes + " " + timerSec + " " + secunds);
			//disabledButton();
		}

		private void radioButton2_CheckedChanged_1(object sender, EventArgs e)
		{

		}

		private void button3_Click(object sender, EventArgs e)
		{
            if (i == numbQuest) button1.Visible = true;
            if (i >= 1 && i < numbQuest)
			{
				i--;
				vivod(i);
				currentQuestion = i;
				//disableButton();
			}
		}

		private void timer1_Tick_1(object sender, EventArgs e)
        {
            TimerCalculation();
            testTimer.Text = timerMin + " : " + timerSec;
            timer++;
            if (timer > 599)
            {
                TimerCalculation();
                timer1.Enabled = false;
                double resultPercentage;
                for (int j = 0; j < numbQuest; j++)
                {
                    finishSum += Test[j].rez;
                }
                resultPercentage = finishSum > 18 ? 5 : finishSum > 16 ? 4 : finishSum > 14 ? 3 : 2;
                RecordFile(resultPercentage, finishSum);
                MinutesAndSeconds();
                MessageBox.Show("Время истекло. Вы ответили на " + finishSum + " " + finishQuestions + ". Ваша оценка " + resultPercentage + "\nВремя выполнения " + timerMin + " " + minutes + " " + timerSec + " " + secunds);
                //disabledButton();

            }
        }

        private void RecordFile(double resultPercentage, double finishSum)
        {
			// throw new NotImplementedException();
			StreamWriter resultFile;
			if (File.Exists(@"../result.txt"))
				resultFile = File.AppendText(@"../result.txt");
			else
				resultFile = File.CreateText(@"../result.txt");
			resultFile.WriteLine("Тест завершен. Было отвечено на " + finishSum + " " + finishQuestions);
			resultFile.WriteLine("Поставлена оценка: " + resultPercentage);
			resultFile.WriteLine("Время выполнения: " + timerMin + " " + minutes + " " + timerSec + " " + secunds);
			resultFile.Close();
		}

        private void Form2_Load(object sender, EventArgs e)
        {

        }
    }
}
